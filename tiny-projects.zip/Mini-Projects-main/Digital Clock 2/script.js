const $ = (selector) => document.querySelector(selector);

const hour = $(".hour");
const colon = $(".colon");
const min = $(".min");
const weeks = $(".weeks");
const dateDisplay = $(".date");

let showColon = true;

function update() {
    showColon = !showColon;
    const now = new Date();

    colon.classList.toggle("invisible", showColon);

    hour.textContent = String(now.getHours()).padStart( 2, "0");
    min.textContent = String(now.getMinutes()).padStart( 2, "0");

    // Highlight correct day of the week
    Array.from(weeks.children).forEach((ele) => ele.classList.remove("active"));
    weeks.children[now.getDay()].classList.add("active");

    // Set date
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    dateDisplay.textContent = now.toLocaleDateString(undefined, options);
}

setInterval(update, 500);
update();                  // Initial call
