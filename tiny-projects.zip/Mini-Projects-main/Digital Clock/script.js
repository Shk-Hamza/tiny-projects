const hoursEl = document.getElementById('hours');
const minutesEl = document.getElementById('minutes');
const secondsEl = document.getElementById('seconds');

function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');

    updateElement(hoursEl, hours);
    updateElement(minutesEl, minutes);
    updateElement(secondsEl, seconds);
}

function updateElement(el, newValue) {
    if (el.textContent !== newValue) {
        el.textContent = newValue;
        el.classList.add('animate');
        setTimeout(() => el.classList.remove('animate'), 300);
    }
}

updateClock();
setInterval(updateClock, 1000);








//------------------------------------------------------------------------------------------------------------


// Step by Step Simple Explanation:

// 1.
// const hoursEl = document.getElementById('hours');


// Yeh line web page mein se "hours" naam ka element dhundhti hai (jo HTML mein id="hours" hota hai).
// Aur us element ko hoursEl naam ke variable mein store kar leti hai.
// Taake hum aage us element ko use kar saken (jahan hours dikhana hai).

// 2.
// const minutesEl = document.getElementById('minutes');


// Yeh bhi waise hi hai jaise pehle waali line.
// Yeh minutes ke liye HTML element ko dhundhta hai.
// Aur usse minutesEl variable mein rakhta hai.

// 3.
// const secondsEl = document.getElementById('seconds');


// Same cheez seconds ke liye.
// HTML element jiska id="seconds" hai, usko secondsEl variable mein rakhta hai.

// 4.
// function updateClock() {


// Yeh ek function bana rahe hain, jiska naam updateClock hai.
// Function matlab ek kaam jo aap baar baar kar sakte ho.
// Yeh function jab bhi chalega, toh humari clock update ho jayegi.

// 5.
// const now = new Date();


// Yeh line abhi ka waqt aur date le kar ek object banati hai.
// Is object mein hours, minutes, seconds sab kuch hota hai.
// now variable mein abhi ki date aur time store hota hai.

// 6.
// const hours = String(now.getHours()).padStart(2, '0');


// now.getHours() se abhi ke ghante milte hain (0 se 23 tak).
// String(...) use isliye kiya taake number ko text (string) mein badal sake.
// .padStart(2, '0') ka matlab hai: agar sirf 1 digit ka number hai (jaise 5), toh uske aage ek '0' lagao (to ban jaye "05").
// Taake time hamesha 2 digits ka dikhai de.

// 7.
// const minutes = String(now.getMinutes()).padStart(2, '0');


// Yeh waise hi hai jaise hours wali line.
// Bas yeh minutes le raha hai.
// Phir usko string bana kar, 2 digits mein convert kar raha hai (e.g., "03").

// 8.
// const seconds = String(now.getSeconds()).padStart(2, '0');


// Yeh bhi bilkul same, lekin seconds ke liye hai.
// Taake seconds bhi 2 digit format mein dikhain.

// 9.
// updateElement(hoursEl, hours);


// Yeh function call karta hai updateElement ko.
// Pehla argument: HTML element jisme hum hours dikhate hain (hoursEl).
// Dusra argument: abhi ka hour value jo humne nikal ke string banaya (hours).
// Matlab: "hours" ko HTML mein update karo.

// 10.
// updateElement(minutesEl, minutes);


// Wahi kaam minutes ke liye.
// Minutes element ko update karo naye minutes ke saath.

// 11.
// updateElement(secondsEl, seconds);


// Aur yeh seconds element ko update karta hai.
// Har baar jab yeh function chalega, ye 3 parts update hote hain.

// 12.
// function updateElement(el, newValue) {


// Yeh ek aur function hai jiska naam updateElement hai.
// Yeh function ek HTML element el aur ek naya value newValue lega.
// Aur is function ka kaam hai woh element ka content update karna.

// 13.
// if (el.textContent !== newValue) {


// Yeh check karta hai:
// Kya element ka current content (jo page pe dikh raha hai) newValue se alag hai?
// Agar alag hai tabhi update kare warna nahi.

// 14.
// el.textContent = newValue;


// Agar value alag thi toh yeh us element ka text content update karta hai.
// Matlab page pe jo time dikh raha tha, usse replace karta hai nayi value se.

// 15.
// el.classList.add('animate');


// Yeh line us element ko 'animate' naam ka CSS class add karti hai.
// 'animate' class CSS mein likhi hoti hai jo thodi animation dikhata hai (jaise thoda bada karna).
// Yeh animation effect time change hone pe dikhta hai.

// 16.
// setTimeout(() => el.classList.remove('animate'), 300);


// Yeh thodi der (300 milliseconds) baad 'animate' class ko element se hata deta hai.
// Isliye animation sirf thodi der ke liye hota hai, phir wapas normal ho jata hai.
// setTimeout ek timer hota hai jo delay ke baad koi kaam karta hai.

// 17.
// updateClock();


// Yeh line turant clock update karta hai jaise hi page load hota hai.
// Toh time pehle se hi show ho jata hai bina delay ke.

// 18.
// setInterval(updateClock, 1000);


// Yeh line har 1000 milliseconds (1 second) ke baad updateClock function ko chalata hai.
// Matlab clock har second apne aap update hoti rahegi.

// Summary:

// Hum HTML elements ko variables mein rakhtay hain.
// Phir har second abhi ka time nikalte hain.
// Phir wo time HTML mein update karte hain.
// Jab value change ho to animation bhi dikhate hain.
// Aur ye sab kaam automatically har second repeat hota hai.