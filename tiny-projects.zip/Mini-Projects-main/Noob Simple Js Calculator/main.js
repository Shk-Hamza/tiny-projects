let num1 = document.getElementById("num1")
let num2 = document.getElementById("num2")
let add = document.getElementById("add")
let subtract = document.getElementById("subtract")
let multiply = document.getElementById("multiply")
let divide = document.getElementById("divide")
let ans = document.getElementById("ans")

function fun_add() { 
    let result = parseFloat(num1.value) + parseFloat(num2.value)
    ans.innerText = result
}

add.onclick = fun_add


function fun_subtract() { 
    let result = parseFloat(num1.value) - parseFloat(num2.value)
    ans.innerText = result
}

subtract.onclick = fun_subtract


function fun_multiply() { 
    let result = parseFloat(num1.value) * parseFloat(num2.value)
    ans.innerText = result
}

multiply.onclick = fun_multiply


function fun_divide() { 
    let result = parseFloat(num1.value) / parseFloat(num2.value)
    ans.innerText = result
}

divide.onclick = fun_divide