const display = document.getElementById('display');
const clickSound = document.getElementById('clickSound');
const equalSound = document.getElementById('equalSound');

function playSound() {
    clickSound.currentTime = 0;
    clickSound.play();
}

function append(value) {
    playSound();
    if (display.textContent === '0') display.textContent = '';
    display.textContent += value;
}

function clearDisplay() {
    playSound();
    display.textContent = '0';
}

function deleteLast() {
    playSound();
    if (display.textContent.length > 1) {
        display.textContent = display.textContent.slice(0, -1);
    } else {
        clearDisplay();
    }
}

function calculate() {
    equalSound.currentTime = 0;
    equalSound.play();

    try {
        display.textContent = eval(display.textContent);
    } catch {
        display.textContent = 'Error';
    }
}


document.addEventListener('keydown', (e) => {
    const key = e.key;
    if ((/\d|[+\-*/%.]/).test(key)) {
        append(key);
    } else if (key === 'Enter') {
        calculate();
    } else if (key === 'Backspace') {
        deleteLast();
    } else if (key.toLowerCase() === 'c') {
        clearDisplay();
    }
});







//---------------------------------------------------------------------------------------------------



// 🔢 Code Breakdown — Line by Line


// 📍 Step 1: HTML ke elements ko JavaScript mein lena

// const display = document.getElementById('display');
// const clickSound = document.getElementById('clickSound');
// const equalSound = document.getElementById('equalSound');

// 🔍 Meaning:

// display: Calculator ka screen jahan result ya numbers dikhte hain.
// clickSound: Ek sound jo button dabane pe bajta hai (except equal).
// equalSound: Sirf = button ke liye alag sound.

// 🧪 Example:

// Aap HTML mein likh chuke ho:

// <div id="display">0</div>
// <audio id="clickSound" src="click.mp3"></audio>
// <audio id="equalSound" src="equal.mp3"></audio>


// 📍 Step 2: Sound bajana (function banaya)

// function playSound() {
//     clickSound.currentTime = 0;
//     clickSound.play();
// }

// 🔍 Meaning:

// currentTime = 0: Sound dubara 0 se start ho jaye har baar
// play(): Sound ko play karna

// 🔔 Used for: All buttons except equal


// 📍 Step 3: append(value) – Jab user koi number/operator click kare

// function append(value) {
//     playSound();
//     if (display.textContent === '0') display.textContent = '';
//     display.textContent += value;
// }

// 🔍 Meaning:

// Agar display mein 0 hai, to pehle usse hata do
// Fir jo bhi user click kare, usko += ka matlab: pehle se jo likha hai uske baad lagao

// 💡 Example:

// Display mein 0 hai → Click 2 → Show: 2
// Fir click + → Show: 2+


// 📍 Step 4: clearDisplay() – "Clr" button ka function

// function clearDisplay() {
//     playSound();
//     display.textContent = '0';
// }

// 💡 Example:

// Chahe aapne 9823+123 likha ho, "Clr" dabate hi screen becomes 0.


// 📍 Step 5: deleteLast() – "DEL" button ka function

// function deleteLast() {
//     playSound();
//     if (display.textContent.length > 1) {
//         display.textContent = display.textContent.slice(0, -1);
//     } else {
//         clearDisplay();
//     }
// }

// 🔍 Meaning:

// slice(0, -1): Last character delete karo
// Agar ek hi character bacha hai (2), to usse delete karke 0 karo

// 📍 Step 6: calculate() – "=" Button ka kaam

// function calculate() {
//     equalSound.currentTime = 0;
//     equalSound.play();

//     try {
//         display.textContent = eval(display.textContent);
//     } catch {
//         display.textContent = 'Error';
//     }
// }

// 🔍 Important Points:

// eval(): Jo bhi expression likha hai, uska result nikaal do
// Agar galat expression ho to error dikhado
// Aur equalSound alag se bajao

// 💡 Examples:

// 2+3*4 → Output: 14

// 2+*4 → Invalid → Output: Error

// 📍 Step 7: Keyboard se control

// document.addEventListener('keydown', (e) => {
//     const key = e.key;
//     if ((/\d|[+\-*/%.]/).test(key)) {
//         append(key);
//     } else if (key === 'Enter') {
//         calculate();
//     } else if (key === 'Backspace') {
//         deleteLast();
//     } else if (key.toLowerCase() === 'c') {
//         clearDisplay();
//     }
// });

// 🔍 Meaning:

// Jab user keyboard press kare:
// Agar number ya +, -, etc. ho → screen pe likho
// Agar Enter dabaya → Calculate
// Agar Backspace dabaya → Delete last
// Agar C dabaya → Clear

//===================================================================================================


// 👀 Full Line:

// document.addEventListener('keydown', (e) => {
//     const key = e.key;
//     if ((/\d|[+\-*/%.]/).test(key)) {
//         append(key);



// 🔍 1. document.addEventListener('keydown', (e) => { ... })

// 💬 Meaning:

// Jab user keyboard ka koi bhi key dabaye (like 1, +, Enter, etc.), toh yeh function chalega.


// 🧠 Example:

// User ne keyboard se 5 press kiya → is function ke andar ka code chalega.
// User ne + dabaya → same function chalega.

// 🔍 2. const key = e.key;

// 💬 Meaning:

// e.key se hum us key ka naam lete hain jo press hui hai. Usse hum key naam ke variable mein rakh rahe hain.

// 🧠 Example:

// Agar user 7 press kare → key = '7'
// Agar user + press kare → key = '+'
// Agar user Enter press kare → key = 'Enter'

// 🔍 3. if ((/\d|[+\-*/%.]/).test(key)) {

// 💬 Scary Lag Raha? Chill, It’s Easy!

// Ye Regular Expression (short: RegEx) hai.
// Let’s break it down:

// ✨ Expression:
//                  /\d|[+\-*/%.]/

// 🧠 Meaning:
// Symbol	                    Meaning
// /.../	               RegEx ka start and end
// \d	                   Any digit (0 to 9)
// `	                   `
// [+\-*/%.]	           +, -, *, /, %, . — ye sab allowed

// So overall:

// 👉 Ye condition check karti hai:
// "Kya pressed key koi number ya operator (+, -, etc.) hai?"


// 🔍 4. .test(key)

// 💬 Meaning:
//             RegEx se hum check karte hain ki key allowed hai ya nahi.

// 🧠 Example:

// test('5')     => true
// test('+')     => true
// test('a')     => false
// test('Enter') => false


// 🔍 5. append(key);

// 💬 Meaning:

// Agar key allowed hai (digit ya operator), toh append() function call karo, jo screen pe wo key show karta hai.

// 🧠 Example:

// Press 5 → append('5') → Screen pe 5
// Press + → append('+') → Screen pe + add ho jata hai

// ✅ Final Simple Meaning (1 Line Mein):

// Jab user koi number ya + - * / % . keyboard se press kare, toh calculator screen par wo value add ho jaye.


// 🔄 Visual Flow:

// User presses key on keyboard
//     ↓
// Is the key a digit or + - * / % . ?
//     ↓
// Yes → Add it to screen using append()
// No  → Ignore (or check other conditions like Enter, Backspace etc.)



//===================================================================================================



// 🔔 Summary (Super Short):

// Function	                    what does it do ? 

// append()	                Display mein add karta hai
// clearDisplay()	        Display ko clear karta hai
// deleteLast()	            Last character delete karta hai
// calculate()	            Result nikalta hai
// playSound()	            Button click pe sound bajata hai
// equalSound	            Equal pe special sound