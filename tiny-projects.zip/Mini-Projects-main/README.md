# Mini Projects

A minimal concept built with attention to detail and smooth behavior.

— Bilal Butt